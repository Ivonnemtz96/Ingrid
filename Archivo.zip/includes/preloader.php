<div class="preloader">
    <div class="counter">0</div>
</div>