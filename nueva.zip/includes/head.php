<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dra. Ingrid Quintero</title>
    <link rel="icon" href="/assets/images/icon/logo-icon.png" type="image/gif" sizes="20x20">

    <link rel="stylesheet" href="/assets/css/all.css">

    <link rel="stylesheet" href="/assets/css/bootstrap.min.css">

    <link rel="stylesheet" href="/assets/css/boxicons.min.css">

    <link rel="stylesheet" href="/assets/css/bootstrap-icons.css">

    <link rel="stylesheet" href="/assets/css/jquery-ui.css">

    <link rel="stylesheet" href="/assets/css/swiper-bundle.css">

    <link rel="stylesheet" href="/assets/css/nice-select.css">

    <link rel="stylesheet" href="/assets/css/magnific-popup.css">

    <link rel="stylesheet" href="/assets/css/jquery.fancybox.min.css">

    <link rel="stylesheet" href="/assets/css/odometer.css">

    <link rel="stylesheet" href="/assets/css/style.css">

     <!-- captcha -->
     <script src="https://www.google.com/recaptcha/api.js" async defer></script>
</head>